$("button").click(function() {
  sweetAlert("Oops...", "Something went wrong!", "error");
});